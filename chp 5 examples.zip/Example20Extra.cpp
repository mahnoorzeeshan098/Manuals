#include <iostream>
using namespace std;

int main()
{
    int sum, num;

    sum = 0;
    cin >> num;
    while (cin)
    {
            if (num < 0) 
            {
                cout << "Negative number found in the data." << endl;
                break;
            }
        sum = sum + num;
        cin >> num;
    }
}