#include<iostream>
using namespace std;

int main()
{
    int newNum, Average, Sum=0;

    for(int i = 1; i<=5; i++)
    {
        cin >> newNum;
        Sum = Sum + newNum;
    }
    Average = Sum/5;
    cout<<"The Sum is = "<<Sum<<endl;
    cout<<"The Average is = "<<Average<<endl;
}