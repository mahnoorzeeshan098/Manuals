#include <iostream>
using namespace std;

int main()
{
    // a
    int i = 11;
    {
        while (i <= 10)
            cout << i << " ";
        i = i + 5;
    }
    cout << endl;

    // b
    i = 11;
    do
    {
        cout << i << " ";
        i = i + 5;
    } while (i <= 10);
    cout << endl;

    int score;
    do
    {
        cout << "Enter a score between 0 and 50: ";
        cin >> score;
        cout << endl;
    }
    while (score < 0 || score > 50);
}