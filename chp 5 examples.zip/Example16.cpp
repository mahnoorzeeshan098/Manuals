#include <iostream>
using namespace std;

int main()
{
    int nthFibonacci, current, previous1=0, previous2=1;
    
    cout<<"Enter Number of Fibonacci Series = ";
    cin>>nthFibonacci;

    for (int counter = 1; counter <= nthFibonacci; counter++)
    {
        current = previous2 + previous1;
        previous1 = previous2;
        previous2 = current;
        cout<<current<<" ";
    }
}