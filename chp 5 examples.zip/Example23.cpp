#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    ifstream infile("InputFile_Eg23and24.txt");
    if (!infile)
    {
        cout << "Cannot open input file." << endl;
        return 1;
    }

    int counter = 0;
    while (counter < 5)
    {
        int num, sum = 0;
        infile >> num;
        while (num != -999)
        {
            sum = sum + num;
            infile >> num;
        }
        cout << "Line " << counter << ": Sum = " << sum << endl;
        counter++;
    }

    infile.close();
    return 0;
}
