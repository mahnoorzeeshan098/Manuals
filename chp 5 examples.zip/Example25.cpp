#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main()
{
    ifstream infile("Example25_InputFile.txt");
    if (!infile)
    {
        cout << "Cannot open input file." << endl;
        return 1;
    }

    int ID, num, sum;
    char ch;
    string name;

    infile >> ID;

    while (infile)
    {
        infile.get(ch);
        getline(infile, name);
        sum = 0;
        infile >> num;
        while (num != -999)
        {
            sum = sum + num;
            infile >> num;
        }
        cout << "Name: " << name << ", Votes: " << sum << endl;
        infile >> ID;
    }

    infile.close();
    return 0;
}
