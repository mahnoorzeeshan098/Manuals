#include <iostream>
#include <string>
using namespace std;


void showLocations(char word[]) {
    cout << "\nAlphabet positions in the array:\n";

    
    for (int i = 0; word[i] != '\0'; i++) {
        cout << "Alphabet '" << word[i] << "' is at position " << i << endl;
    }
}

int main() {
    char word[50];   

    cout << "Enter a word: ";
    cin >> word;     

    showLocations(word);  

    return 0;
}
