#include <iostream>
using namespace std;

// Function to print the array in reverse order
void printReverse(int arr[], int n) {
    cout << "\nNumbers in reverse order:\n";

    for (int i = n - 1; i >= 0; i--) {
        cout << arr[i] << " ";
    }
    cout << endl;
}

int main() {
    int n;

    cout << "How many numbers do you want to enter? ";
    cin >> n;

    int arr[100];   // array of max size 100

    cout << "Enter " << n << " numbers:\n";
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    printReverse(arr, n);  // call function

    return 0;
}
