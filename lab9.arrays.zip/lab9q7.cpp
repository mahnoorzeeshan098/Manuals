#include <iostream>
using namespace std;

int main() {
    string word;

    cout << "Enter a word: ";
    cin >> word;

    // Go through each letter of the string
    for (int i = 0; word[i] != '\0'; i++) {

        // If letter is 'z', change to 'a'
        if (word[i] == 'z') {
            word[i] = 'a';
        }
        // If letter is 'Z', change to 'A' (optional uppercase handling)
        else if (word[i] == 'Z') {
            word[i] = 'A';
        }
        else {
            // Otherwise change letter to the next letter
            word[i] = word[i] + 1;
        }
    }

    cout << "Output: " << word << endl;

    return 0;
}
