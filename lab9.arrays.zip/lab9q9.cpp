#include <iostream>
using namespace std;

// Function that returns the largest number
int findLargestNumber(int arr[], int size) {
    int largest = arr[0];   // assume first number is largest

    for (int i = 1; i < size; i++) {
        if (arr[i] > largest) {
            largest = arr[i];   // update largest
        }
    }

    return largest;
}

int main() {
    int n;
    int arr[100];

    cout << "How many numbers do you want to enter? ";
    cin >> n;

    cout << "Enter " << n << " numbers:\n";
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    int largest = findLargestNumber(arr, n);  // function call

    cout << "The largest number is: " << largest << endl;

    return 0;
}
