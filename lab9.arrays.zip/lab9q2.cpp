#include<iostream>
using namespace std;
int main()
{
    int n;
    cout<<"Enter numbers: ";
    cin>>n;
     int arr[n];
    for(int i=0;i<=n;i++)
    {
        cin>>arr[i];
    
    }
    for(int idx=0; idx<n; idx++)
    {
        cout<<arr[idx]<<" ";
    }
     cout<<endl;
}