#include <iostream>
using namespace std;

// Function to display the string in reverse order
void displayReverse(string str) {
    int length = 0;

    // Count the length of the string manually
    while (str[length] != '\0') {
        length++;
    }

    cout << "Reversed string: ";

    // Print in reverse using the counted length
    for (int i = length - 1; i >= 0; i--) {
        cout << str[i];
    }

    cout << endl;
}

int main() {
    string word;

    cout << "Enter a word: ";
    cin >> word;

    displayReverse(word);

    return 0;
}
