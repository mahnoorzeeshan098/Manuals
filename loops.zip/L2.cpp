#include<iostream>
using namespace std;
main()
{
    int n;
    cout<<"Enter your triangle number"<<endl;
    cin>>n;
    int p= n*(n+1)/2;
    cout<<"The number of dots are"<<p<<endl;
}