#include<iostream>
using namespace std;
main()
{
    int n;
    int i;
    cin>>n;
    double weight;
    double totalweight=0
    double truckweight=0;
    double busweight=0;
    double trainweight=0;
    for(i=0;i<=n;i++)
    cin>>weight;
     totalWeight += weight;

        if (weight <= 3)
            busWeight += weight;        
        else if (weight <= 11)
            truckWeight += weight;      
        else
            trainWeight += weight; 
            double totalCost = (busWeight * 200) + (truckWeight * 175) + (trainWeight * 120);
    double averagePricePerTon = totalCost / totalWeight;
    double busPercent = (busWeight / totalWeight) * 100;
    double truckPercent = (truckWeight / totalWeight) * 100;
    double trainPercent = (trainWeight / totalWeight) * 100;

cout << averagePricePerTon << endl;
    cout << busPercent << "%" << endl;
    cout << truckPercent << "%" << endl;
    cout << trainPercent << "%" << endl;


}